import QuakesController from "./quakeController";

let quaker = new QuakesController;
quaker.init();